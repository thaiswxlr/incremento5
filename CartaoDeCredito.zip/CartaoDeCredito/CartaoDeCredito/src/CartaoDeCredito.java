import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CartaoDeCredito {
    private String numero;
    private float limite;
    private float saldo;
    private float cashbackRate;
    private List<Transacao> historicoDeTransacoes; 
  

    public CartaoDeCredito(String numero, float limiteInicial) {
        this.numero = numero;
        this.limite = limiteInicial;
        this.saldo = 0.0f;
        this.cashbackRate = 0.0f;
        this.historicoDeTransacoes = new ArrayList<>();
    }

    public CartaoDeCredito(String numero, float limiteInicial, float cashbackRate) {
        this.numero = numero;
        this.limite = limiteInicial;
        this.saldo = 0.0f;
        this.cashbackRate = cashbackRate;
        this.historicoDeTransacoes = new ArrayList<>();
    }


    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public float getLimite() {
        return limite;
    }

    public void setLimite(float limite) {
        this.limite = limite;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getCashbackRate() {
        return cashbackRate;
    }

    public void setCashbackRate(float cashbackRate) {
        this.cashbackRate = cashbackRate;
    }
 
    public float consultarLimite() {
        return getLimite();
    }

    public float consultarSaldo() {
        return getSaldo();
    }

    public List<Transacao> getHistoricoDeTransacoes() {
        return historicoDeTransacoes;
    }

    public void realizarTransacao(float valor, String descricao, boolean comCashback) {
        if (valor <= 0) {
            System.out.println("O valor da transação deve ser positivo.");
            return;
        }

        if (valor <= getLimite()) {
            setLimite(getLimite() - valor);
            setSaldo(getSaldo() + valor);

            float cashback = 0.0f;
            if (comCashback) {
                cashback = valor * getCashbackRate();
                setLimite(getLimite() + cashback);
                System.out.printf("Transação realizada com cashback de R$%.2f!%n", cashback);
            } else {
                System.out.println("Transação realizada com sucesso!");
            }
            Transacao transacao = new Transacao(new Date(), valor, descricao);
            historicoDeTransacoes.add(transacao);
        } else {
            System.out.println("Limite insuficiente para realizar a transação.");
        }
    }

    public void exibirHistoricoDeTransacoes() {
        if (historicoDeTransacoes.isEmpty()) {
            System.out.println("Nenhuma transação realizada.");
        } else {
            System.out.println("Histórico de Transações:");
            for (Transacao transacao : historicoDeTransacoes) {
                System.out.println(transacao);
            }
        }
    }
}







    